#packages used

#'@import testthat
#'@import stringr
#'@import dplyr
#'@import knitr
