library(testthat)
library(binomialpkg)

test_check("binomialpkg")
